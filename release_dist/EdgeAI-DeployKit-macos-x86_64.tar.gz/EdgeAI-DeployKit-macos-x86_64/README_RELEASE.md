# EdgeAI-DeployKit Release Package

Target: `macos-x86_64`

This package contains the local WebUI, FastAPI backend, `edgeai` CLI source,
task-aware local inference flow, and report generation code.

## Quick Start

### Windows

Prerequisites:

- Windows 10/11 x86_64
- Python 3.10-3.12 on PATH
- Node.js 20+ with Corepack, or network access so `start-windows.bat`
  can download a portable Node.js runtime into `.runtime/`
- Network access to Python/npm package indexes on first start

Double-click:

```text
start-windows.bat
```

The first run creates `.venv`, installs Python dependencies, installs WebUI
dependencies, starts the FastAPI backend and Next.js WebUI, then opens:

```text
http://127.0.0.1:3000/workspace
```

Stop both services:

```text
stop-windows.bat
```

If Python is missing, double-click:

```text
install-runtime-windows.bat
```

### Linux

```bash
scripts/install-linux.sh
./start-linux.sh
```

For PyTorch `.pt` / `.pth` conversion support:

```bash
scripts/install-linux.sh --with-pytorch
```

For TensorFlow/Keras conversion support:

```bash
scripts/install-linux.sh --with-tensorflow
```

For both PyTorch and TensorFlow/Keras conversion support:

```bash
scripts/install-linux.sh --with-pytorch --with-tensorflow
```

### macOS

Prerequisites:

- macOS on Intel x86_64 or Apple Silicon arm64
- Python 3.10+ (`brew install python@3.12` is recommended)
- Node.js 20+ with Corepack (`brew install node && corepack enable`)

Install and start:

```bash
./install-macos.sh
./start-macos.sh
```

Stop services:

```bash
./start-macos.sh stop
```

### Manual Backend

```bash
python -m pip install -e .[pdf]
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

Windows users can run `start-backend.bat` and `start-ui.bat`. macOS/Linux
users can run `./start-linux.sh`, or run `./start-backend.sh` and `./start-ui.sh`
in separate terminals.

## Notes

- Generated packages, reports, rootfs images, ONNX Runtime SDKs, `node_modules`,
  and model weights are intentionally excluded from this archive.
- Put user models under `inputs/models/` or upload them from the WebUI.
- The local path is: Convert -> Analyze -> Task Init -> Prepare Input ->
  Local Run -> Task Render -> Report.
