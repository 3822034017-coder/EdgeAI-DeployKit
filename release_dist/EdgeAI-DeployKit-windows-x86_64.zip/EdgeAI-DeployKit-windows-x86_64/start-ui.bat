@echo off
setlocal
cd /d %~dp0\product-ui
set NEXT_PUBLIC_API_BASE=http://127.0.0.1:8000
pnpm install --frozen-lockfile
pnpm dev --hostname 127.0.0.1 --port 3000
