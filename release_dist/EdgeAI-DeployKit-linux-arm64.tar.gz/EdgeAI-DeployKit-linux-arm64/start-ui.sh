#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/product-ui"
API_PORT="${EDGEAI_API_PORT:-8000}"
UI_HOST="${EDGEAI_UI_HOST:-127.0.0.1}"
UI_PORT="${EDGEAI_UI_PORT:-3000}"
export NEXT_PUBLIC_API_BASE="${NEXT_PUBLIC_API_BASE:-http://127.0.0.1:${API_PORT}}"
if command -v corepack >/dev/null 2>&1; then
  corepack pnpm install --frozen-lockfile
  corepack pnpm dev --hostname "$UI_HOST" --port "$UI_PORT"
elif command -v pnpm >/dev/null 2>&1; then
  pnpm install --frozen-lockfile
  pnpm dev --hostname "$UI_HOST" --port "$UI_PORT"
else
  echo "[ERROR] pnpm/Corepack not found. Install Node.js 20+ and rerun scripts/install-linux.sh." >&2
  exit 1
fi
