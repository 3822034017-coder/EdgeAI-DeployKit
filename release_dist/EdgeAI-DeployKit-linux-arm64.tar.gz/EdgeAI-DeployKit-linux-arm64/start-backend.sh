#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ -f ".venv/bin/activate" ]; then source ".venv/bin/activate"; fi
PY="${PYTHON_BIN:-python3}"
if [ -x ".venv/bin/python" ]; then PY=".venv/bin/python"; fi
API_HOST="${EDGEAI_API_HOST:-127.0.0.1}"
API_PORT="${EDGEAI_API_PORT:-8000}"
"$PY" -m uvicorn backend.main:app --host "$API_HOST" --port "$API_PORT"
